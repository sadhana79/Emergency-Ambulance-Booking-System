<?php
include("config.php");
extract($_POST);
$query  = "INSERT INTO `contactdata`(`firstname`, `lastname`, `phone`, `email`, `message`) VALUES ('".$firstname."','".$lastname."',".$phone.",'".$email."','".$message."')";
$res = mysqli_query($conn,$query);
if(!$res){
    die("Couldn't enter data: ".$res->error);
}
echo "Thank You For Contacting Us ";

?>






<?php
include('./mainInclude/header.php');

?>
<div class="heading" style="background:url(uploads/header-bg-1.png) no-repeat">
   <h1>Contact us</h1>
</div>
<html>
<head>
    <title>Contact us</title>
    <link rel="stylesheet" href="contact.css?v=<?php echo time();?>">
</head>

<body>
    <div class="container">
        <h2>Contact Form </h2><br>
        <form action="contact-process.php" method="POST">
            <div class="form-group">
                <label for="firstname">Firstname</label>
                <input type="text" name="firstname" id="firstname" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="lastname">Lastname</label>
                <input type="text" name="lastname" id="lastname" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone</label>
                <input type="tel" name="phone" id="phone" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="message">Message</label>
                <textarea  rows="4" cols="2" name="message" id="message" class="form-control" required></textarea>
            </div>
            <div class="form-group">
        <button class="btn btn-success" type="submit">Submit</button>
        <button class="btn btn-danger" type="reset">Reset</button>
    </div>
        </form>
    </div>
</body>

</html>
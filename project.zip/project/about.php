
<?php
include('./mainInclude/header.php');
?>
<div class="heading" style="background:url(uploads/header-bg-1.png) no-repeat">
   <h1>about us</h1>
</div>


<section class="about">

   <div class="image">
      <img src="uploads/about.png" alt="">
   </div>

   <div class="content">
      <h3>why choose us?</h3>
      <p>we EABS,situated at area,city is a reputed and committed ambulance provider.
         we are committed to provide excellent and critical care services in emergencies</p>
      <p>we are recognised for our passionate care,we take to improve standard critical care transport.
         we feel honored and privilaged that our pre-existing clients have positive feedback towards us.</p>
      <div class="icons-container">
         <div class="icons">
            <i class="fas fa-map"></i>
            <span>fastest response</span>
         </div>
         
         <div class="icons">
            <i class="fas fa-headset"></i>
            <span>24/7 service</span>
         </div>

         <div class="icons">
            <i class="fas fa-map"></i>
            <span>experienced staff</span>
         </div>
      </div>
   </div>

</section>




<?php
include('./mainInclude/footer.php');
?>















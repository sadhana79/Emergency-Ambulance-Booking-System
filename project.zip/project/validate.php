<script>
$(document).ready(function() {
  $("form").validate({
    rules: {
      fname: {
        required: true,
        minlength: 3,
        maxlength: 20,
        lettersOnly: true
      },
      lname: {
        required: true,
        minlength: 3,
        maxlength: 20,
        lettersOnly: true
      },
      username: {
        required: true,
        minlength: 3,
        maxlength: 50,
        usernamePattern: true
      },
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5,
        maxlength: 20,
        passwordPattern: true
      },
      passwordConfirm: {
        required: true,
        equalTo: "#password"
      }
    },
    messages: {
      fname: {
        minlength: "First Name: Minimum 3 characters are required.",
        maxlength: "First Name: Maximum 20 characters are allowed.",
        lettersOnly: "Invalid Entry for First Name."
      },
      // Add similar messages for other fields
    }
  });

  // Custom validation methods
  jQuery.validator.addMethod("lettersOnly", function(value, element) {
    return /^[A-Za-z _]*[A-Za-z ]+[A-Za-z _]*$/.test(value);
  }, "Invalid Entry. Please enter letters without any Digit or special symbols.");

  jQuery.validator.addMethod("usernamePattern", function(value, element) {
    return /^[^0-9][a-z0-9]+([_-]?[a-z0-9])$/.test(value);
  }, "Invalid Entry for Username. Enter lowercase letters without spaces.");

  jQuery.validator.addMethod("passwordPattern", function(value, element) {
    return /^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]*$/.test(value);
  }, "The password does not meet the requirements.");
});
</script>

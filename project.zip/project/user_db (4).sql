-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2023 at 09:31 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintable`
--

CREATE TABLE `admintable` (
  `id` int(11) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admintable`
--

INSERT INTO `admintable` (`id`, `user`, `pass`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `ambulancelist`
--

CREATE TABLE `ambulancelist` (
  `vehicleno` varchar(255) NOT NULL,
  `ambulancetype` varchar(255) NOT NULL,
  `drivername` varchar(255) NOT NULL,
  `licenseno` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `ambulance_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ambulancelist`
--

INSERT INTO `ambulancelist` (`vehicleno`, `ambulancetype`, `drivername`, `licenseno`, `city`, `ambulance_id`) VALUES
('AVN202130221121300', 'Basic Life Support Ambulance', 'jay sharma', 'L456789', 'pune', 1),
('AVN20231030411212620', 'Advanced Life Support Ambulance', 'raj mishra', 'L365674', 'Nanded', 2),
('AVN202310403121300', 'Basic Life Support Ambulance', 'athrva', 'L43434665', 'parbhani', 3),
('AVN2023105001213814', 'Patient Transfer Ambulance', 'ritesh', 'L657789', 'pune', 4);

-- --------------------------------------------------------

--
-- Table structure for table `contactdata`
--

CREATE TABLE `contactdata` (
  `id` int(11) NOT NULL,
  `firstname` varchar(55) NOT NULL,
  `lastname` varchar(55) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(55) NOT NULL,
  `message` text NOT NULL,
  `attachement` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contactdata`
--

INSERT INTO `contactdata` (`id`, `firstname`, `lastname`, `phone`, `email`, `message`, `attachement`) VALUES
(1, 'sadhana', 'Patil', '9156701585', 'sadhanagonge@gmail.com', 'happy', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pass_reset`
--

CREATE TABLE `pass_reset` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pass_reset`
--

INSERT INTO `pass_reset` (`id`, `email`, `token`) VALUES
(1, 'sadhanagonge@gmail.com', '7b5c66eb9836a78e6ed4d13779c646e5364f6cbde6787561da3931a31923742af8360b355f81ebd48d3956cfa3dbc89b817a');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_name` text NOT NULL,
  `service_desc` text NOT NULL,
  `service_img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_name`, `service_desc`, `service_img`) VALUES
(1, 'Basic Ambulance', 'These types of ambulances are the basic ambulances that we commonly see in our daily lives. Basic ambulances are handled by an emergency medical technician (EMT) and transport patients who require basic medical supervision under minor or uncritical situations such as mild fractures, and sub-acute care facilities (nursing homes). It comprises of the patient bed, pulse oximetry and oxygen delivery devices.  ', '../uploadss5.jpg'),
(2, 'Advance Ambulance', 'Advance ambulances are equipped with advanced equipment and tools to handle critically ill patients. They are also equipped with an ECG monitor, defibrillator, intravenous and blood drawing tools, etc. Patients who require a high level of care and who are fighting for life need services like hospital emergency department or critical care unit need advance ambulance services. ', '../uploadss1.jpg'),
(4, 'Neonatal Ambulance', 'The neonatal ambulance is baby-friendly and comes equipped with the neonatal ventilators, the AMBU bag, and other specialized medical equipment. With an experienced doctor and trained paramedics being present during the NICU baby interfacility transportation.', '../uploadss2.jpg'),
(12, 'Mortuary Ambulance:', 'These ambulances are mainly for the transportation of a dead body. Irrespective of the types of ambulance in India, all of them are equipped with basic life-saving equipment and medicines for emergency. Ambulance cost depends on the types of ambulance services you opt that varies from Rs 800 - 4000 for 10 Km distance.', '../uploadss8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(255) DEFAULT NULL,
  `lname` varchar(255) DEFAULT NULL,
  `username` varchar(300) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `date` date NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `mobileno` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `username`, `email`, `password`, `date`, `image`, `mobileno`) VALUES
(1, 'Sadhana', 'Gonge', 'sadhana', 'sadhanagonge@gmail.com', '$2y$04$VFAcAPSCC5VPILmpWw32mO0rwolF1bbVhAxATY5DXgYq5.cO2f1ee', '2023-11-03', 'profile_831636577.jpg', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintable`
--
ALTER TABLE `admintable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ambulancelist`
--
ALTER TABLE `ambulancelist`
  ADD PRIMARY KEY (`ambulance_id`);

--
-- Indexes for table `contactdata`
--
ALTER TABLE `contactdata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pass_reset`
--
ALTER TABLE `pass_reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admintable`
--
ALTER TABLE `admintable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ambulancelist`
--
ALTER TABLE `ambulancelist`
  MODIFY `ambulance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contactdata`
--
ALTER TABLE `contactdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `pass_reset`
--
ALTER TABLE `pass_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
